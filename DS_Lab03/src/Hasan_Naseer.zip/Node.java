/* *@author - Hasan Naseer
   * @category Data Structures -- CSC 2420 
   * Lab 03 - Node */ 
public class Node {
	int item;
	Node next;
	
	//Node constructor 
	
	Node(int d){
		item =d;
		next = null;
	}
}
